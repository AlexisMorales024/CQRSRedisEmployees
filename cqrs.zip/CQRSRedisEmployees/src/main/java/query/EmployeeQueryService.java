package query;

import java.util.List;

import com.google.gson.Gson;

import database.RedisConnection;
import dto.EmployeeDTO;
import redis.clients.jedis.Jedis;

public class EmployeeQueryService {

    private EmployeeQueryRepository repository =
            new EmployeeQueryRepository();

    private Gson gson = new Gson();

    public List<EmployeeDTO> getEmployees() {

        String key = "empleados";

        try (Jedis jedis = RedisConnection.getConnection()) {

            String json = jedis.get(key);

            if (json != null) {

                System.out.println(
                        "DATOS OBTENIDOS DESDE REDIS"
                );

                EmployeeDTO[] array =
                        gson.fromJson(
                                json,
                                EmployeeDTO[].class
                        );

                return List.of(array);
            }

      

            List<EmployeeDTO> employees =
                    repository.getEmployees();

            jedis.set(
                    key,
                    gson.toJson(employees)
            );

            return employees;
        }
    }
}