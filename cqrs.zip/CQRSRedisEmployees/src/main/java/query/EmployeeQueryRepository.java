package query;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import database.MySQLConnection;
import dto.EmployeeDTO;

public class EmployeeQueryRepository {

	public List<EmployeeDTO> getEmployees() {

		List<EmployeeDTO> employees = new ArrayList<>();

		try {

			Connection conn = MySQLConnection.getConnection();

			Statement st = conn.createStatement();

			String sql = """
					                    SELECT
					    s.salary,
					    e.first_name,
					    e.last_name,
					    e.gender,
					    d.dept_name
					FROM employees.employees e
					JOIN employees.salaries s
					    ON e.emp_no = s.emp_no
					JOIN employees.dept_emp de
					    ON e.emp_no = de.emp_no
					JOIN employees.departments d
					    ON de.dept_no = d.dept_no
					                    """;

			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {

				EmployeeDTO employee = new EmployeeDTO(rs.getDouble("salary"), rs.getString("first_name"),
						rs.getString("last_name"), rs.getString("gender"), rs.getString("dept_name"));

				employees.add(employee);
			}

			rs.close();
			st.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return employees;
	}
}