package database;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySQLConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/employees";

	private static final String USER = "root";

	private static final String PASSWORD = "admin";

	public static Connection getConnection() throws Exception {

		return DriverManager.getConnection(URL, USER, PASSWORD);
	}
}