package main;

import java.util.List;

import dto.EmployeeDTO;
import query.EmployeeQueryService;

public class Main {

    public static void main(String[] args) {

        long inicio = System.nanoTime();

        EmployeeQueryService service =
                new EmployeeQueryService();

        List<EmployeeDTO> employees =
                service.getEmployees();

        long fin = System.nanoTime();

        System.out.println("Cantidad de registros: "
                + employees.size());

        System.out.println("Tiempo de ejecución: "
                + ((fin - inicio) / 1_000_000.0)
                + " ms");
    }
}