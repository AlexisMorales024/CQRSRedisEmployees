package dto;

public class EmployeeDTO {
	private double salary;
	private String firstName;
	private String lastName;
	private String gender;
	private String deptName;

	public EmployeeDTO(double salary, String firstName, String lastName, String gender, String deptName) {

		this.salary = salary;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.deptName = deptName;
	}

	@Override
	public String toString() {

		return "EmployeeDTO [salary=" + salary + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", deptName=" + deptName + "]";
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	
}